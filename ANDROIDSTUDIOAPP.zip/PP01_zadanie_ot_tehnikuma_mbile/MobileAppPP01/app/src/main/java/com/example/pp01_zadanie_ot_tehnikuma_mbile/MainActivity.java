package com.example.pp01_zadanie_ot_tehnikuma_mbile;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    DBHelper dbHelper;
    SQLiteDatabase db;

    EditText loginField, passwordField;
    Button signInButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DBHelper(getApplicationContext());
        dbHelper.createDB(getApplicationContext());
        db = dbHelper.open();

        loginField = findViewById(R.id.loginInput);
        passwordField = findViewById(R.id.passwordInput);

        signInButton = findViewById(R.id.signInButton);
        signInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                signInFunction();
            }
        });
    }

    public void signInFunction(){
        String login = loginField.getText().toString();
        String password = passwordField.getText().toString();

        if(login.isEmpty()){
            toastMaker("Введите логин!");
        }
        else{
            if(password.isEmpty()){
                toastMaker("Введите пароль");
            }
            else{


                String dbPassword = null;

                Cursor cursor = db.rawQuery("select password from employers where login = " + "'" +login + "'",null);
                if(cursor.moveToFirst()){
                    int index = cursor.getColumnIndex("password");
                    do{
                        dbPassword = cursor.getString(index);
                    }
                    while(cursor.moveToNext());

                }
                cursor.close();
                if(dbPassword.equals(password)){
                    int empID = 0;
                    String empSurname = null;
                    String empName = null;
                    String empMidname = null;
                    Cursor empIdQuery = db.rawQuery("select _id from employers where login = '" +login + "'",null);
                    if(empIdQuery.moveToFirst()){
                        int idindex = empIdQuery.getColumnIndex("_id");
                        do{
                            empID = Integer.parseInt(empIdQuery.getString(idindex));
                        }
                        while(empIdQuery.moveToNext());
                    }
                    empIdQuery.close();
                    Cursor empInfoQuery = db.rawQuery("select surname,name,middlename from employers where _id = "+empID,null);
                    if(empInfoQuery.moveToFirst()){
                        int surnameId = empInfoQuery.getColumnIndex("surname");
                        int nameId = empInfoQuery.getColumnIndex("name");
                        int midnameId = empInfoQuery.getColumnIndex("middlename");
                        do{
                            empSurname = empInfoQuery.getString(surnameId);
                            empName = empInfoQuery.getString(nameId);
                            empMidname = empInfoQuery.getString(midnameId);
                        }
                        while(empInfoQuery.moveToNext());
                    }
                    db.close();
                    toastMaker("Вход успешно выполнен!");
                    Intent intent = new Intent(getApplicationContext(),Work.class);
                    intent.putExtra("secondName",empSurname);
                    intent.putExtra("firstName",empName);
                    intent.putExtra("middlename",empMidname);
                    startActivity(intent);

                }
                else{
                    toastMaker("Логин или пароль введены не верно!");
                }
            }
        }
    }

    public void toastMaker(String toastText){
        Toast toast = Toast.makeText(getApplicationContext(),toastText,Toast.LENGTH_LONG);
        toast.show();
    }
}