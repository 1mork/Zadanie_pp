package com.example.pp01_zadanie_ot_tehnikuma_mbile;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.SimpleCursorAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
public class Work extends AppCompatActivity{

    Boolean multipleQueryOn = false;
    TextView empWho;
    AutoCompleteTextView orderNumber;
    Button confirmButton, viewOrderButton;
    ImageView addOrderInQuery, addNewClientButton;
    String orderNumberString;
    int orderNumberPlus;
    Spinner serviceCollection;
    int selectedService;
    Spinner clientsCollection;
    int selectedClient;
    //List<String> addedOrders = new List<String>(){""};
    ArrayList<String> addedOrders = new ArrayList<String>();

    ArrayList<String> autocomplete = new ArrayList<String>();

    ArrayList<String> orderNumbers = new ArrayList<String>();
    ArrayList<Integer> orderClients = new ArrayList<Integer>();
    ArrayList<Integer> ordersServices = new ArrayList<Integer>();

    DBHelper dbHelper;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.work);
    }

    @Override
    protected void onStart() {
        super.onStart();
        serviceCollection = findViewById(R.id.serviceCollection);
        clientsCollection = findViewById(R.id.clientsCollection);

        confirmButton = findViewById(R.id.confirmButton);
        viewOrderButton = findViewById(R.id.viewOrderButton);
        addOrderInQuery = findViewById(R.id.imageView2);

        empWho = (TextView)findViewById(R.id.employSNM);

        Intent intent = getIntent();

        String empSurname = intent.getStringExtra("secondName");
        String empName = intent.getStringExtra("firstName");
        String empMidname = intent.getStringExtra("middlename");

        String employer = "Вы вошли как " + empSurname + "." + empName.substring(0,1) + "." + empMidname.substring(0,1);

        empWho.setText(employer);

        //Подсказка для номера закакза

        dbHelper = new DBHelper(getApplicationContext());
        db = dbHelper.open();

        Cursor cursor = db.rawQuery("select order_code from orders order by _id desc limit 1",null);
        if(cursor.moveToFirst()){
            int stringIndex = cursor.getColumnIndex(DBHelper.Orders.COLUMN_ORDER_CODE);
            do{
                orderNumberString = cursor.getString(stringIndex);
            }
            while(cursor.moveToNext());
            String [] splittedOrderNumber = orderNumberString.split("/");
            orderNumberPlus = Integer.parseInt(splittedOrderNumber[0]);
            orderNumberPlus++;
            autocomplete.add(String.valueOf(orderNumberPlus));
        }

        orderNumber = findViewById(R.id.orderNumberInput);
        orderNumber.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line,autocomplete));

        cursor.close();

        //Выпадающий список услуг

        Cursor serviceQuery = db.rawQuery("select _id,name from services",null);
        SimpleCursorAdapter serviceAdapter = new SimpleCursorAdapter(getApplicationContext(), android.R.layout.simple_spinner_item,serviceQuery,new String[] {"name"},new int[]{android.R.id.text1});
        serviceAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        serviceCollection.setAdapter(serviceAdapter);

        serviceCollection.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
                selectedService = Math.toIntExact(id);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        //clientsQuery.close();

        //Выпадающий список клиентов
        Cursor clientsQuery = db.rawQuery("select _id,surname || ' ' || name || ' ' || patronymic as fio from clients",null);
        SimpleCursorAdapter clientsAdapter = new SimpleCursorAdapter(getApplicationContext(), android.R.layout.simple_spinner_item,clientsQuery,new String[]{"fio"},new int[]{android.R.id.text1});
        clientsAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        clientsCollection.setAdapter(clientsAdapter);

        clientsCollection.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                selectedClient = Math.toIntExact(l);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        //Оформление заказа
        confirmButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                orderConfirmation();
            }
        });

        //Просмотр заказов
        viewOrderButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                db.close();
                autocomplete.clear();
                Intent viewOredersIntent = new Intent(getApplicationContext(),OrderList.class);
                startActivity(viewOredersIntent);
            }
        });

        //Кнопка добавление услуги к заказу
        addOrderInQuery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                multipleOrder();
            }
        });

        //Кнопка перехода к добавление нового клиента
        addNewClientButton = findViewById(R.id.imageView3);
        addNewClientButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                db.close();
                autocomplete.clear();
                Intent addNewClient = new Intent(getApplicationContext(),AddClient.class);
                startActivity(addNewClient);
            }
        });




    }

    public void orderConfirmation(){

        int servicesListLastId  =0;

        Cursor getServicesListLastId= db.rawQuery("select _id from services_list order by _id DESC limit 1",null);
        if(getServicesListLastId.moveToFirst()){
            int index = getServicesListLastId.getColumnIndex("_id");
            do{
                servicesListLastId = Integer.parseInt(getServicesListLastId.getString(index));
            }
            while(getServicesListLastId.moveToNext());
        }

        //lastId + 1;
        servicesListLastId++;


        String fullOrderNumber = orderNumber.getText() + "/" + LocalDateTime.now().format(DateTimeFormatter.ISO_DATE).toString();


        if(multipleQueryOn){
            ContentValues cv = new ContentValues();
            for(int i = 0; i < ordersServices.size(); i++){
                int servicesListLastIdInCircle  =0;

                Cursor getServicesListLastIdInCircle= db.rawQuery("select _id from services_list order by _id DESC limit 1",null);
                if(getServicesListLastIdInCircle.moveToFirst()){
                    int index = getServicesListLastIdInCircle.getColumnIndex("_id");
                    do{
                        servicesListLastIdInCircle = Integer.parseInt(getServicesListLastIdInCircle.getString(index));
                    }
                    while(getServicesListLastIdInCircle.moveToNext());
                }
                getServicesListLastIdInCircle.close();

                //lastId + 1;
                servicesListLastIdInCircle++;


                cv.put(DBHelper.Orders.COLUMN_ORDER_CODE,fullOrderNumber);
                cv.put(DBHelper.Orders.COLUMN_CLIENT_ID,selectedClient);
                cv.put(DBHelper.Orders.COLUMN_SERVICE_LIST_ID,servicesListLastIdInCircle);
                db.insert("orders",null,cv);
                cv.clear();


                Cursor newCS = db.rawQuery("select _id from orders group by _id order by _id DESC limit 1",null);
                if(newCS.moveToFirst()){
                    int columnIndex = newCS.getColumnIndex("_id");
                    do{
                        addedOrders.add(newCS.getString(columnIndex));
                    }
                    while(newCS.moveToNext());
                }
                newCS.close();

                ContentValues servicesListContentInCircle = new ContentValues();
                servicesListContentInCircle.put("order_id",Integer.parseInt(addedOrders.get(addedOrders.size() - 1)));
                servicesListContentInCircle.put("service_id",selectedService);
                db.insert("services_list",null,servicesListContentInCircle);

            }
        }
        else{
            ContentValues contentValues = new ContentValues();
            contentValues.put(DBHelper.Orders.COLUMN_ORDER_CODE,fullOrderNumber);
            contentValues.put(DBHelper.Orders.COLUMN_CLIENT_ID,selectedClient);
            contentValues.put(DBHelper.Orders.COLUMN_SERVICE_LIST_ID,servicesListLastId);

            long result = db.insert("orders",null,contentValues);
        }

        //+данные в services_list

        Cursor newCursor = db.rawQuery("select _id from orders group by _id order by _id DESC limit 1",null);
        if(newCursor.moveToFirst()){
            int columnIndex = newCursor.getColumnIndex("_id");
            do{
                addedOrders.add(newCursor.getString(columnIndex));
            }
            while(newCursor.moveToNext());
        }
        newCursor.close();

        ContentValues servicesListContent = new ContentValues();
        servicesListContent.put("order_id",Integer.parseInt(addedOrders.get(addedOrders.size() - 1)));
        servicesListContent.put("service_id",selectedService);
        db.insert("services_list",null,servicesListContent);

        orderNumber.setEnabled(true);
        clientsCollection.setEnabled(true);


    }

    public void multipleOrder(){

        multipleQueryOn = true;

        ordersServices.add(selectedService);

        orderNumber.setEnabled(false);
        clientsCollection.setEnabled(false);

    }

    public void toastMaker(String toastText){
        Toast toast = Toast.makeText(getApplicationContext(),toastText,Toast.LENGTH_LONG);
        toast.show();
    }
}
