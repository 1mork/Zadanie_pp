﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using PP01_Lib;


namespace UnitTestProject
{

    [TestClass]
    public class test_nu
    {
        [TestMethod]
        public void one()
        {
            TimeSpan timeSpan1 = new TimeSpan(8, 10, 0);
            TimeSpan timeSpan2 = new TimeSpan(12, 45, 0);
            TimeSpan timeSpan3 = new TimeSpan(16, 15, 0);
            TimeSpan[] startTimes = new TimeSpan[] { timeSpan1, timeSpan2, timeSpan3 };
            int[] durations = new int[] { 10, 5, 15 };
            TimeSpan beginWorkingTime = new TimeSpan(8, 0, 0);
            TimeSpan endWorkingTime = new TimeSpan(18, 0, 0);
            int consultationTime = 45;
            string[] expected = new string[] { "080:20:00-09:05:00", "09:05:00-09:50:00", "09:50:00-10:35:00", "10:35:00-11:20:00", "11:20:00-12:05:00", "12:50:00-13:35:00", "13:35:00-14:20:00", "14:20:00-15:05:00", "15:05:00-15:50:00", "16:30:00-17:15:00", "17:15:00-18:00:00" };
            string[] actual;
            actual = PP01_Lib.Class1.AvailablePeriods(startTimes, durations, beginWorkingTime, endWorkingTime, consultationTime);
            for (int i = 0; i < actual.Length; i++)
            {
                Assert.AreEqual(expected[i], actual[i]);
            }
        }

        [TestMethod]
        public void two()
        {
            TimeSpan timeSpan1 = new TimeSpan(8, 0, 0);
            TimeSpan[] startTimes = new TimeSpan[] { timeSpan1 };
            int[] durations = new int[] { 10 };
            TimeSpan beginWorkingTime = new TimeSpan(8, 0, 0);
            TimeSpan endWorkingTime = new TimeSpan(10, 0, 0);
            int consultationTime = 50;
            string[] expected = new string[] { "08:10:00-09:000:00", "09:00:00-09:50:00" };
            string[] actual;
            actual = PP01_Lib.Class1.AvailablePeriods(startTimes, durations, beginWorkingTime, endWorkingTime, consultationTime);
            for (int i = 0; i < actual.Length; i++)
            {
                Assert.AreEqual(expected[i], actual[i]);
            }
        }

        [TestMethod]
        public void three()
        {
            TimeSpan timeSpan1 = new TimeSpan(16, 50, 0);
            TimeSpan timeSpan2 = new TimeSpan(17, 20, 0);
            TimeSpan[] startTimes = new TimeSpan[] { timeSpan1, timeSpan2 };
            int[] durations = new int[] { 30, 40 };
            TimeSpan beginWorkingTime = new TimeSpan(16, 0, 0);
            TimeSpan endWorkingTime = new TimeSpan(19, 0, 0);
            int consultationTime = 35;
            string[] expected = new string[] { "16:00:00-16:35:00", "18:00:00-18:35:00" };
            string[] actual;
            actual = PP01_Lib.Class1.AvailablePeriods(startTimes, durations, beginWorkingTime, endWorkingTime, consultationTime);
            for (int i = 0; i < actual.Length; i++)
            {
                Assert.AreEqual(expected[i], actual[i]);
            }
        }

        [TestMethod]
        public void four()
        {
            TimeSpan timeSpan1 = new TimeSpan(11, 0, 0);
            TimeSpan timeSpan2 = new TimeSpan(14, 0, 0);
            TimeSpan[] startTimes = new TimeSpan[] { timeSpan1, timeSpan2 };
            int[] durations = new int[] { 15, 30 };
            TimeSpan beginWorkingTime = new TimeSpan(10, 0, 0);
            TimeSpan endWorkingTime = new TimeSpan(16, 0, 0);
            int consultationTime = 60;
            string[] expected = new string[] { "10:00:00-11:00:00", "11:15:00-12:15:00", "12:15:00-13:15:00", "14:30:00-15:30:00" };
            string[] actual;
            actual = PP01_Lib.Class1.AvailablePeriods(startTimes, durations, beginWorkingTime, endWorkingTime, consultationTime);
            for (int i = 0; i < actual.Length; i++)
            {
                Assert.AreEqual(expected[i], actual[i]);
            }
        }

        [TestMethod]
        public void five()
        {
            TimeSpan timeSpan1 = new TimeSpan(8, 0, 0);
            TimeSpan timeSpan2 = new TimeSpan(11, 0, 0);
            TimeSpan timeSpan3 = new TimeSpan(12, 10, 0);
            TimeSpan timeSpan4 = new TimeSpan(13, 10, 0);
            TimeSpan[] startTimes = new TimeSpan[] { timeSpan1, timeSpan2, timeSpan3, timeSpan4 };
            int[] durations = new int[] { 50, 10, 10, 10 };
            TimeSpan beginWorkingTime = new TimeSpan(6, 0, 0);
            TimeSpan endWorkingTime = new TimeSpan(14, 0, 0);
            int consultationTime = 55;
            string[] expected = new string[] { "06:00:00-06:55:00", "06:55:00-07:50:00", "08:50:00-09:45:00", "09:45:00-10:40:00", "11:10:00-12:05:00" };
            string[] actual;
            actual = PP01_Lib.Class1.AvailablePeriods(startTimes, durations, beginWorkingTime, endWorkingTime, consultationTime);
            for (int i = 0; i < actual.Length; i++)
            {
                Assert.AreEqual(expected[i], actual[i]);
            }

        }
    }
    [TestClass]
    public class test_eu
    {
        [TestMethod]
        public void oneone()
        {
            TimeSpan timeSpan1 = new TimeSpan(8, 0, 0);
            TimeSpan timeSpan2 = new TimeSpan(15, 0, 0);
            TimeSpan[] startTimes = new TimeSpan[] { timeSpan1, timeSpan2 };
            int[] durations = new int[] { 90, 90 };
            TimeSpan beginWorkingTime = new TimeSpan(8, 0, 0);
            TimeSpan endWorkingTime = new TimeSpan(18, 0, 0);
            int consultationTime = 70;
            string[] expected = new string[] { "09:30:00-10:40:00", "10:40:00-11:50:00", "11:50:00-13:00:00", "13:00:00-14:10:00", "16:30:00-17:40:00" };
            string[] actual;
            actual = PP01_Lib.Class1.AvailablePeriods(startTimes, durations, beginWorkingTime, endWorkingTime, consultationTime);
            for (int i = 0; i < actual.Length; i++)
            {
                Assert.AreEqual(expected[i], actual[i]);
            }

        }

        [TestMethod]
        public void twotwo()
        {
            TimeSpan timeSpan1 = new TimeSpan(9, 0, 0);
            TimeSpan[] startTimes = new TimeSpan[] { timeSpan1 };
            int[] durations = new int[] { 120 };
            TimeSpan beginWorkingTime = new TimeSpan(8, 0, 0);
            TimeSpan endWorkingTime = new TimeSpan(13, 0, 0);
            int consultationTime = 80;
            string[] expected = new string[] { "11:00:00-12:20:00" };
            string[] actual;
            actual = PP01_Lib.Class1.AvailablePeriods(startTimes, durations, beginWorkingTime, endWorkingTime, consultationTime); 
            for (int i = 0; i < actual.Length; i++)
            {
                Assert.AreEqual(expected[i], actual[i]);
            }
        }

        [TestMethod]
        public void threethree()
        {
            TimeSpan timeSpan1 = new TimeSpan(16, 50, 0);
            TimeSpan timeSpan2 = new TimeSpan(17, 20, 0);
            TimeSpan[] startTimes = new TimeSpan[] { timeSpan1, timeSpan2 };
            int[] durations = new int[] { 90, 40 };
            TimeSpan beginWorkingTime = new TimeSpan(14, 0, 0);
            TimeSpan endWorkingTime = new TimeSpan(19, 0, 0);
            int consultationTime = 150;
            string[] expected = new string[] { "14:00:00-16:30:00" };
            string[] actual;
            actual = PP01_Lib.Class1.AvailablePeriods(startTimes, durations, beginWorkingTime, endWorkingTime, consultationTime);
            for (int i = 0; i < actual.Length; i++)
            {
                Assert.AreEqual(expected[i], actual[i]);
            }
        }
    }
    [TestClass]
    public class test_iu
    {
        [TestMethod]
        public void on1()
        {
            TimeSpan timeSpan1 = new TimeSpan(99, 0, 0);
            TimeSpan timeSpan2 = new TimeSpan(120, 0, 0);
            TimeSpan[] startTimes = new TimeSpan[] { timeSpan1, timeSpan2 };
            int[] durations = new int[] { 90, 900 };
            TimeSpan beginWorkingTime = new TimeSpan(2, 0, 0);
            TimeSpan endWorkingTime = new TimeSpan(0, 0, 0);
            int consultationTime = 800;
            string[] expected = new string[] { "Null" };
            string[] actual;
            actual = PP01_Lib.Class1.AvailablePeriods(startTimes, durations, beginWorkingTime, endWorkingTime, consultationTime); 
            for (int i = 0; i < actual.Length; i++)
            {
                Assert.AreEqual(expected[i], actual[i]);
            }
        }
        [TestMethod]
        public void tw2()
        {
            TimeSpan timeSpan1 = new TimeSpan(9999, -1, -0);
            TimeSpan[] startTimes = new TimeSpan[] { timeSpan1 };
            int[] durations = new int[] { -0 };
            TimeSpan beginWorkingTime = new TimeSpan(18, 0, 0);
            TimeSpan endWorkingTime = new TimeSpan(13, 0, 0);
            int consultationTime = 0;
            string[] expected = new string[] { "Null" };
            string[] actual;
            actual = PP01_Lib.Class1.AvailablePeriods(startTimes, durations, beginWorkingTime, endWorkingTime, consultationTime);
            for (int i = 0; i < actual.Length; i++)
            {
                Assert.AreEqual(expected[i], actual[i]);
            }

        }
    }
}
