﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PP01_Lib
{
    public class Class1
    {
        public static string[] AvailablePeriods(TimeSpan[] startTimes, int[] durations, TimeSpan beginWorkingTime, TimeSpan endWorkingTime, int consultationTime)
        {
            try
            {
                List<string> rez = new List<string>();
                TimeSpan consultationTimeSpan = new TimeSpan(0, consultationTime, 0); // Промежуток консультации
                TimeSpan OneMin = new TimeSpan(0, 1, 0); // 1 минута для проверки
                TimeSpan ProverkaTimeSpan = new TimeSpan(); // промежуточная переменная для проверки

                ProverkaTimeSpan = beginWorkingTime;
                int triger = -1;

                if (ProverkaTimeSpan == startTimes[0])
                {
                    TimeSpan durationsTimeSpan = new TimeSpan(0, durations[0], 0);
                    ProverkaTimeSpan = startTimes[0] + durationsTimeSpan;
                }

                for (int iX = 0; iX != triger; iX++)
                {
                    for (int i = 0; i < consultationTime; i++)
                    {
                        ProverkaTimeSpan = ProverkaTimeSpan + OneMin;
                        for (int j = 0; j < startTimes.Length; j++)
                        {
                            if (ProverkaTimeSpan == startTimes[j] && i == consultationTime - 1)
                            {
                                rez.Add(ProverkaTimeSpan - consultationTimeSpan + "-" + ProverkaTimeSpan);
                                TimeSpan durationsTimeSpan = new TimeSpan(0, durations[j], 0);
                                ProverkaTimeSpan = startTimes[j] + durationsTimeSpan;
                                i = -1;
                            }
                            else if (ProverkaTimeSpan == startTimes[j] && i != consultationTime - 1)
                            {
                                TimeSpan durationsTimeSpan = new TimeSpan(0, durations[j], 0);
                                ProverkaTimeSpan = startTimes[j] + durationsTimeSpan;
                                i = -1;
                            }
                            else if (ProverkaTimeSpan != startTimes[j] && i == consultationTime - 1 && iX != -2 && ProverkaTimeSpan < endWorkingTime)
                            {
                                rez.Add(ProverkaTimeSpan - consultationTimeSpan + "-" + ProverkaTimeSpan);
                                i = -1;
                            }

                            if (ProverkaTimeSpan == endWorkingTime && i == consultationTime - 1)
                            {
                                rez.Add(ProverkaTimeSpan - consultationTimeSpan + "-" + ProverkaTimeSpan);

                                iX = -2;
                                i = -1;
                            }
                            else if (ProverkaTimeSpan == endWorkingTime && i != consultationTime - 1)
                            {
                                iX = -2;

                                i = -1;
                            }
                            else if (ProverkaTimeSpan > endWorkingTime)
                            {
                                iX = -2;
                            }
                        }
                    }
                }

                string[] result = new string[rez.Count];
                for (int i = 0; i < rez.Count; i++)
                {
                    result[i] = rez[i];
                }

                if (rez.Count == 0)
                {
                    string[] nuls = new string[1];
                    nuls[0] = "Null";
                    return nuls;
                }
                return result;
            }
            catch
            {
                string[] result = new string[1];
                result[0] = "Error!";
                return result;
            }
        }
    }
}
